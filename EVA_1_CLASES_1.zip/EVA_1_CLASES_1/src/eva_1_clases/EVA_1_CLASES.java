
package eva_1_clases;

public class EVA_1_CLASES {
    public static void main(String[] args) {
        //  UNA CLASE SIRVE PARA CREAR OBJETOS: 
        //1. DECLRARAR UN IDENTIFICADOR DEL TIPO DE LA CLASE
        Persona perso1;
        //2.    INSTANCIAR EL OBJETO--> new (crfea el objeto en memoria
        // Identificador = new NOMBRE_DE_LA_CLASE(argumentos);
       perso1 = new Persona();
       System.out.println(perso1);//REFERENCIA 
        Persona perso2 = new Persona();
       System.out.println(perso2);//REFERENCIA 
        String Guerra = null;
       perso1.apellido = Guerra;  
       
}
   
}
//
class Persona{
    // Estado--> Datos (variables) --> ATRIBUTOS
 String nombre; // default-->solo es visible dentrod el mismo paquete
  public String apellido; //--> se puede ver todas las clases en los paquetes 
private int edad; //--> visible SOLO dentro de la clase
    // Comportamiuento --> Metodos
    void imprimir () {
      System.out.println("Nombre+Apellido");
    }
}