
public class EVA1_4_ENCAPSULAMIENTO {

//ATRIBUTOS
private String nombre;
private String apellido;
private int edad;
private char genero;
// CONSRUCTRORES 
// COMPORTAMINENTO: //interfaz
//get y set = obtener y escritura
public String getnombre (){
    return nombre;
    
}
public void setnombre (String valor){
    nombre = valor;
    
}

    public String getapellido (){
    return apellido;
    }
void setapellido (String valor){
        apellido = valor;
        
        
    }
}


