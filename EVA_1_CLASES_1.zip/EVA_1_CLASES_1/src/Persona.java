
public class Persona {
    
    // Estado--> Datos (variables) --> ATRIBUTOS
 String nombre; // default-->solo es visible dentrod el mismo paquete
  public String apellido; //--> se puede ver todas las clases en los paquetes 
private int edad; //--> visible SOLO dentro de la clase
 perso.
}
