
package eva1_4_encapsulamiento;

class Persona {
    String getNombre;
    String getApellido;
    String getEdad;

    public Persona() {
    }

    void setNombre(String david) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    void setApellido(String guerra) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    void setEdad(String edad) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    void setGenero(String h) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    String getGenero() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    void imprimirdatos() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}
