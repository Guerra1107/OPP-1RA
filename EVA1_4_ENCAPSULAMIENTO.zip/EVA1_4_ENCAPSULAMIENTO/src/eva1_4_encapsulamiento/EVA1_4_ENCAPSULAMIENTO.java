
package eva1_4_encapsulamiento;
public class EVA1_4_ENCAPSULAMIENTO {
    public static void main(String[] args) {
        persona perso = new persona();

        perso.setNombre("David");
        perso.setApellidos("Guerra");
        perso.setEdad(18);          
        perso.setGenero('H'); 

        System.out.println("Nombre: " + perso.getNombre());
        System.out.println("Apellido: " + perso.getApellidos());
        System.out.println("Edad: " + perso.getEdad());
        System.out.println("Género: " + perso.getGenero());
        perso.imprimirDatos(); 
    }

    private static class persona {

        public persona() {
        }

    private String nombre;
    private String apellidos;
    private int edad;
   private char genero;

   public String  getNombre(){
       return nombre; 
   }
    public void setNombre(String valor){   
       nombre = valor;
}    
    public String getApellidos(){
        return apellidos;
    }
    public void setApellidos (String valor){
        apellidos = valor;
    }
    public int getEdad(){
        return edad;
}
     public void setEdad(int valor){
        edad = valor;   
     }
    public char getGenero(){
        return genero;
}
     public void setGenero(char valor){
        genero = valor;  
     }
public void imprimirDatos(){
    System.out.println("Nombre" + nombre);
    System.out.println("Apellidos" + apellidos);
    System.out.println("Edad" + edad);
    System.out.println("Género" + genero);
}
}
        }