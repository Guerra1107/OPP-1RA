package eva1_2_modificadores;

public class EVA1_2_MODIFICADORES {

    public static void main(String[] args) {
        
        Persona perso = new Persona();

        perso.setNombre("David Alexandro");
        perso.setApellidos("Guerra Holguin");
        perso.setEdad(18);
        perso.setGenero("Hombre");
        perso.setCurp("LPGA5");
     
        System.out.println("Nombre: " + perso.getNombre());
        System.out.println("Apellido: " + perso.getApellidos());
        System.out.println("Edad: " + perso.getEdad());
        System.out.println("Genero: " + perso.getGenero());
        System.out.println("Curp: " + perso.getCurp());
    }
}

class Persona {
   
    private String nombre;
    private String apellidos;
    private int edad;
    private String genero;
    private String curp;

    public String getNombre() { return nombre; }
    public void setNombre(String valor) { nombre = valor; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String valor) { apellidos = valor; }

    public int getEdad() { return edad; }
    public void setEdad(int valor) { edad = valor; }

    public String getGenero() { return genero; }
    public void setGenero(String valor) { genero = valor; }

    public String getCurp() { return curp; }
    public void setCurp(String valor) { curp = valor; }
}