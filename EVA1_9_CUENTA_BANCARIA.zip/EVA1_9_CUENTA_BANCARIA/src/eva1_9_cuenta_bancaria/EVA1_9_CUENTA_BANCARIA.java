package eva1_9_cuenta_bancaria;

public class EVA1_9_CUENTA_BANCARIA {
    private String titular;
    private double saldo;

    public String getTitular() {
        return titular;
    }
    public void setTitular(String valor) {
        titular = valor;
    }
    public double getSaldo() {
        return saldo;
    }
    public void depositar(double monto) {
        saldo = saldo + monto;
    }
    public void retirar(double monto) {
        if (monto <= saldo) {
            saldo = saldo - monto;
        } else {
            System.out.println("ERROR: Fondos insuficientes para retirar $" + monto);
        }
    }
    public void imprimirDatos() {
        System.out.println("---------- ESTADO DE CUENTA ----------");
        System.out.println("Titular: " + titular);
        System.out.println("Saldo Actual: $" + saldo);
        System.out.println("--------------------------------------");
    }
    public static void main(String[] args) {
        EVA1_9_CUENTA_BANCARIA cuenta = new EVA1_9_CUENTA_BANCARIA();
        
        cuenta.setTitular("David Guerra");
        cuenta.depositar(1000.0);
        cuenta.depositar(500.0);
        cuenta.retirar(1800.0);
        cuenta.imprimirDatos();
    }
}