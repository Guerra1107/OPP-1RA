
package eva1_1_clases;

public class EVA1_1_CLASES {
    public static void main(String[] args) {
     Persona persol;       
     persol = new Persona();
     System.out.println(persol); 
     Persona perso2 = new Persona(); 
     System.out.println(perso2);
     persol.apellido = "Guerra";
     persol.nombre = "David";
     persol.edad = 18;      
     perso2.apellido = "Guerra";
     persol.nombre = "David";
     persol.edad = 18;     
     
     
    }
    
}
class Persona{
    String nombre;
    String apellido;
     int edad;
     void imprimir(){
         System.out.println("Nombre: " + nombre);
         System.out.println("Apellido: " + apellido);
         System.out.println("Edad: " + edad);
         
     }  
}