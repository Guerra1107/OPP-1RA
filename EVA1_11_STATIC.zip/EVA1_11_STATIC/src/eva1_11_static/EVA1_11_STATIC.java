package eva1_11_static;


public class EVA1_11_STATIC {

    
    public static void main(String[] args) {
        System.out.println("CLASE");
        System.out.println ("Pi = " + Math.Pi);
        System.out.println ("Valor aleatorio" + Math.random());
        System.out.println ("Potencia (5) = " , Math.pow(5,2));
        
    } 
}
 class Matematicas {
     public final double Pi = 3.14;
 }