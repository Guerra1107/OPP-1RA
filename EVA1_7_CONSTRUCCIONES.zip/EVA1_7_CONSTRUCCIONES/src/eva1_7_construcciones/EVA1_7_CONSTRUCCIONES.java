package eva1_7_construcciones;

public class EVA1_7_CONSTRUCCIONES {

    public static class Persona {
        private String nombre;
        private String apellido;
        private int edad;

        // Constructor
        public Persona() {
            System.out.println("EJECUCIÓN DEL CONSTRUCTOR");
            this.nombre = "----";
            this.apellido = "----";
            this.edad = 0; 
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String valor) {
            this.nombre = valor;
        }

        public String getApellido() {
            return apellido;
        }

        public void setApellido(String valor) {
            this.apellido = valor;
        }

        public int getEdad() {
            return edad;
        }

        public void setEdad(int valor) {
            this.edad = valor;
        }
        
        public void imprimirDatos() {
            System.out.println("Nombre: " + nombre + " " + apellido + " | Edad: " + edad);
        }
    }

    public static void main(String[] args) {

        for (int i = 1; i <= 2; i++) {
            Persona p = new Persona();
            p.setNombre("David");
            p.setApellido("Guerra");
            p.setEdad(18 + i);
            
            p.imprimirDatos();
        }
    }
}