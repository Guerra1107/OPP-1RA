public class EVA1_6_FORMATO_APA {

    private String autor;
    private String titulo;
    private String editorial;
    private String tipo;
    private int año;

    public String getautor() {
        return autor;
    }
    public void setautor(String valor) {
        autor = valor;
    }
    public String gettitulo() {
        return titulo;
    }
    public void settitulo(String valor) {
        titulo = valor;
    }
    public String geteditorial() {
        return editorial;
    }
    public void seteditorial(String valor) {
        editorial = valor;
    }
    public String gettipo() {
        return tipo;
    }
    public void settipo(String valor) {
        tipo = valor;
    }
    public int getaño() {
        return año;
    }
    public void setaño(int valor) {
        año = valor;
    }
    public void imprimirdatos() {
        System.out.println("========= REFERENCIA APA =========");
        System.out.println("Autor: " + autor);
        System.out.println("Año: (" + año + ")");
        System.out.println("Título: " + titulo);
        System.out.println("Editorial: " + editorial);
        System.out.println("Tipo de recurso: " + tipo);
        System.out.println("----------------------------------");
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 2; i++) {
            EVA1_6_FORMATO_APA datos = new EVA1_6_FORMATO_APA();
            
            datos.setautor("Stephen King");
            datos.setaño(2018);
            datos.settitulo("El visitante");
            datos.seteditorial("Plaza & Janés");
            datos.settipo("Libro");

            System.out.println("Registro #" + i);
            datos.imprimirdatos();
        }
    }
}